@extends('layouts.app')

@section('title','Faculties')

@section('content')

@include('partials.page-header',[
    'title' => $selectedRole
        ? $selectedRole.' Access Accounts'
        : 'Faculties',

    'description' => $selectedRole
        ? 'Manage dashboard login accounts assigned to the '.$selectedRole.' role.'
        : 'Manage faculties and their assigned assets.'
])


<style>
.user-table-toolbar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 16px;
    padding: 15px 20px;
    border-bottom: 1px solid #e3eaf1;
}

.user-toolbar-left {
    display: flex;
    align-items: center;
    gap: 8px;
}

.user-toolbar-right {
    display: flex;
    align-items: center;
    justify-content: flex-end;
    gap: 8px;
    margin-left: auto;
}


/* SHOW ENTRIES */

.user-entry-control {
    display: flex;
    align-items: center;
    gap: 8px;
    margin: 0;
    color: #64748b;
    font-size: 14px;
    white-space: nowrap;
}

.user-entry-control .form-select {
    width: 90px;
    height: 44px;
    min-height: 44px;
    border: 1px solid #d8e2eb;
    border-radius: 10px;
    box-shadow: none;
}

.user-entry-control .form-select:focus {
    border-color: #3f5cc4;
    box-shadow: 0 0 0 3px rgba(63,92,196,.08);
}


/* FILTER FORM */

.user-filter-form {
    display: flex;
    align-items: center;
    gap: 8px;
    margin: 0;
}


/* SEARCH */

.user-search {
    position: relative;
    width: 330px;
}

.user-search i {
    position: absolute;
    left: 15px;
    top: 50%;
    transform: translateY(-50%);
    color: #718096;
    pointer-events: none;
}

.user-search input {
    width: 100%;
    height: 44px;
    padding: 0 14px 0 42px;
    border: 1px solid #d8e2eb;
    border-radius: 10px;
    outline: none;
    background: #fff;
}

.user-search input:focus {
    border-color: #3f5cc4;
    box-shadow: 0 0 0 3px rgba(63,92,196,.08);
}


/* STATUS */

.user-status-filter {
    width: 145px;
    height: 44px;
    min-height: 44px;
    border-radius: 10px;
    border-color: #d8e2eb;
}

.user-status-filter:focus {
    border-color: #3f5cc4;
    box-shadow: 0 0 0 3px rgba(63,92,196,.08);
}


/* FOOTER */

.user-table-footer {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
    padding: 15px 20px;
    border-top: 1px solid #e3eaf1;
}

.user-table-info {
    color: #64748b;
    font-size: 14px;
    white-space: nowrap;
}

.user-pagination {
    margin-left: auto;
}

.user-pagination nav,
.user-pagination .pagination {
    margin: 0;
}


/* LOADING */

.user-filter-loading {
    opacity: .65;
    pointer-events: none;
}


@media (max-width: 1200px) {

    .user-table-toolbar {
        flex-wrap: wrap;
    }

    .user-toolbar-right {
        width: 100%;
        flex-wrap: wrap;
        margin-left: 0;
    }

    .user-filter-form {
        flex-wrap: wrap;
    }

    .user-search {
        min-width: 280px;
        flex: 1;
    }
}


@media (max-width: 650px) {

    .user-toolbar-left,
    .user-toolbar-right,
    .user-filter-form {
        width: 100%;
    }

    .user-search {
        width: 100%;
        min-width: 100%;
    }

    .user-status-filter {
        width: 100%;
    }

    .user-table-footer {
        flex-direction: column;
        align-items: flex-start;
    }

    .user-pagination {
        width: 100%;
        margin-left: 0;
    }
}
</style>


{{-- =========================================================
     STATS
========================================================= --}}

<div class="row row-cols-2 row-cols-md-3 g-3 mb-3">

    @include('partials.stat-card',[
        'icon' => 'fa-users',

        'label' => $selectedRole
            ? 'Login Accounts'
            : 'Faculties',

        'value' => number_format(
            $stats['total']
        )
    ])


    @include('partials.stat-card',[
        'icon' => 'fa-user-check',
        'label' => 'Active',
        'value' => number_format($stats['active']),
        'class' => 'success'
    ])


    @include('partials.stat-card',[
        'icon' => 'fa-user-slash',
        'label' => 'Inactive',
        'value' => number_format($stats['inactive']),
        'class' => 'warning'
    ])

</div>


<div class="panel">


    {{-- =====================================================
         HEADER
    ====================================================== --}}

    <div class="panel-header">

        <div>

            <h2>
                {{ $selectedRole
                    ? $selectedRole.' Login Directory'
                    : 'Asset Assignee Directory'
                }}
            </h2>

            <p>
                {{ $users->total() }}

                {{ $selectedRole
                    ? 'dashboard accounts'
                    : 'faculties'
                }}

                available
            </p>

        </div>


        {{-- ADD BUTTON --}}

        @permission('users','create')

            <button
                class="btn btn-primary"
                type="button"
                data-bs-toggle="modal"
                data-bs-target="#createUserModal"
            >

                <i
                    class="fa-solid {{ $selectedRole ? 'fa-key' : 'fa-user-plus' }} me-2"
                ></i>

                {{ $selectedRole
                    ? 'Add Access Account'
                    : 'Add Faculty'
                }}

            </button>

        @endpermission

    </div>


    {{-- =====================================================
         DATATABLE TOOLBAR
    ====================================================== --}}

    <div class="user-table-toolbar">


        {{-- LEFT: SHOW ENTRIES --}}

        <div class="user-toolbar-left">

            <form
                method="GET"
                action="{{ route('users.index') }}"
                class="user-entry-control"
            >

                {{-- Preserve Role --}}

                @if($selectedRole)

                    <input
                        type="hidden"
                        name="role"
                        value="{{ $selectedRole }}"
                    >

                @endif


                {{-- Preserve Search --}}

                @if(request('search'))

                    <input
                        type="hidden"
                        name="search"
                        value="{{ request('search') }}"
                    >

                @endif


                {{-- Preserve Status --}}

                @if(request('status'))

                    <input
                        type="hidden"
                        name="status"
                        value="{{ request('status') }}"
                    >

                @endif


                <span>
                    Show
                </span>


                <select
                    name="per_page"
                    class="form-select form-select-sm"
                    onchange="this.form.submit()"
                    aria-label="Rows per page"
                >

                    @foreach([10,25,50,100] as $size)

                        <option
                            value="{{ $size }}"
                            @selected(
                                (int) request('per_page',10)
                                === $size
                            )
                        >
                            {{ $size }}
                        </option>

                    @endforeach

                </select>


                <span>
                    entries
                </span>

            </form>

        </div>


        {{-- RIGHT --}}

        <div class="user-toolbar-right">


            {{-- SEARCH + STATUS --}}

            <form
                method="GET"
                action="{{ route('users.index') }}"
                id="userFilterForm"
                class="user-filter-form"
            >

                @if($selectedRole)

                    <input
                        type="hidden"
                        name="role"
                        value="{{ $selectedRole }}"
                    >

                @endif


                <input
                    type="hidden"
                    name="per_page"
                    value="{{ request('per_page',10) }}"
                >


                {{-- SEARCH --}}

                <div class="user-search">

                    <i class="fa-solid fa-magnifying-glass"></i>

                    <input
                        name="search"
                        id="userSearch"
                        type="search"
                        value="{{ request('search') }}"
                        placeholder="Search name, email, contact or faculty ID..."
                        autocomplete="off"
                    >

                </div>


                {{-- STATUS --}}

                <select
                    name="status"
                    class="form-select user-status-filter user-auto-filter"
                    aria-label="Status filter"
                >

                    <option value="">
                        All Status
                    </option>

                    <option
                        value="Active"
                        @selected(
                            request('status') === 'Active'
                        )
                    >
                        Active
                    </option>

                    <option
                        value="Inactive"
                        @selected(
                            request('status') === 'Inactive'
                        )
                    >
                        Inactive
                    </option>

                </select>

            </form>


            {{-- CLEAR FILTER --}}

            @if(
                request('search')
                ||
                request('status')
            )

                <a
                    href="{{ route(
                        'users.index',
                        array_filter([
                            'role' => $selectedRole,
                            'per_page' => request(
                                'per_page',
                                10
                            ),
                        ])
                    ) }}"
                    class="btn btn-soft btn-icon"
                    title="Clear filters"
                    aria-label="Clear filters"
                >
                    <i class="fa-solid fa-rotate-left"></i>
                </a>

            @endif


            {{-- EXPORT --}}

            @permission('users','export')

                <a
                    href="{{ route(
                        'users.export',
                        array_filter([
                            ...request()->query(),
                            'role' => $selectedRole,
                        ])
                    ) }}"
                    class="btn btn-soft"
                >
                    <i class="fa-solid fa-file-export me-2"></i>

                    Export
                </a>

            @endpermission


            {{-- IMPORT --}}

            @permission('users','import')

                <button
                    type="button"
                    class="btn btn-soft"
                    data-bs-toggle="modal"
                    data-bs-target="#userImportModal"
                >
                    <i class="fa-solid fa-file-import me-2"></i>

                    Import
                </button>

            @endpermission

        </div>

    </div>


    {{-- =====================================================
         TABLE
    ====================================================== --}}

    <div class="table-responsive">

        <table class="table data-table">

            <thead>
    <tr>

        @if(!$selectedRole)

            <th>S.No.</th>
            <th>User Name</th>
            <th>Deptt.</th>
            <th>New / Old FB</th>
            <th>Room Number</th>
            <th>Phone Number</th>
            <th>Email</th>
            <th>Remark</th>
            <th>Actions</th>

        @else

            <th>User</th>
            <th>User ID</th>
            <th>Access Role</th>
            <th>Contact</th>
            <th>Address</th>
            <th>Status</th>
            <th>Actions</th>

        @endif

    </tr>
</thead>


            <tbody>

                @forelse($users as $user)

                    <tr>

                        @if(!$selectedRole)

                            <td>
                                {{ $users->firstItem() + $loop->index }}
                            </td>

                            <td>
                                <strong>{{ $user->name }}</strong>
                            </td>

                            <td>
                                {{ $user->department?->name ?: '—' }}
                            </td>

                            <td>
                                {{ $user->fb_type ?: '—' }}
                            </td>

                            <td>
                                {{ $user->room_number ?: '—' }}
                            </td>

                            <td>
                                {{ $user->contact ?: '—' }}
                            </td>

                            <td>
                                {{ $user->email ?: '—' }}
                            </td>

                            <td title="{{ $user->remark }}">
                                {{ Str::limit($user->remark, 40) ?: '—' }}
                            </td>

                            <td class="text-nowrap">

                                <a
                                    href="{{ route('users.asset-history', $user) }}"
                                    class="btn btn-soft btn-icon"
                                    title="View details & asset history"
                                >
                                    <i class="fa-regular fa-eye"></i>
                                </a>

                                @permission('users','assign')
                                    <button
                                        class="btn btn-soft btn-icon assign-asset-button"
                                        type="button"
                                        title="Assign asset"
                                        data-bs-toggle="modal"
                                        data-bs-target="#assignAssetModal"
                                        data-user-name="{{ $user->name }}"
                                        data-action="{{ route('users.assign-asset',$user) }}"
                                        @disabled($availableAssets->isEmpty())
                                    >
                                        <i class="fa-solid fa-laptop-file"></i>
                                    </button>
                                @endpermission

                                @permission('users','update')
                                    <button
                                        class="btn btn-soft btn-icon"
                                        type="button"
                                        title="Edit faculty"
                                        data-bs-toggle="modal"
                                        data-bs-target="#editUserModal{{ $user->id }}"
                                    >
                                        <i class="fa-regular fa-pen-to-square"></i>
                                    </button>
                                @endpermission

                                @permission('users','delete')
                                    <form
                                        class="d-inline"
                                        method="POST"
                                        action="{{ route('users.destroy',$user) }}"
                                        data-confirm
                                        data-confirm-title="Delete Faculty?"
                                        data-confirm-message="This will permanently delete {{ $user->name }}."
                                        data-confirm-label="Delete Faculty"
                                    >
                                        @csrf
                                        @method('DELETE')

                                        <button
                                            class="btn btn-soft btn-icon"
                                            type="submit"
                                            title="Delete faculty"
                                        >
                                            <i class="fa-regular fa-trash-can text-danger"></i>
                                        </button>
                                    </form>
                                @endpermission

                            </td>

                        @else

                        {{-- FACULTY --}}

                        <td>

                            <div class="cell-title">

                                @if($user->image_path)

                                    <img
                                        src="{{ \App\Support\PublicUrl::storage($user->image_path) }}"
                                        alt="{{ $user->name }}"
                                        style="
                                            width:42px;
                                            height:42px;
                                            object-fit:cover;
                                            border-radius:50%;
                                        "
                                        onerror="
                                            this.hidden=true;
                                            this.nextElementSibling.hidden=false;
                                        "
                                    >


                                    <span
                                        class="avatar"
                                        hidden
                                    >
                                        {{
                                            collect(
                                                explode(
                                                    ' ',
                                                    $user->name
                                                )
                                            )
                                            ->filter()
                                            ->take(2)
                                            ->map(
                                                fn($part) =>
                                                    Str::upper(
                                                        Str::substr(
                                                            $part,
                                                            0,
                                                            1
                                                        )
                                                    )
                                            )
                                            ->join('')
                                        }}
                                    </span>

                                @else

                                    <span class="avatar">
                                        {{
                                            collect(
                                                explode(
                                                    ' ',
                                                    $user->name
                                                )
                                            )
                                            ->filter()
                                            ->take(2)
                                            ->map(
                                                fn($part) =>
                                                    Str::upper(
                                                        Str::substr(
                                                            $part,
                                                            0,
                                                            1
                                                        )
                                                    )
                                            )
                                            ->join('')
                                        }}
                                    </span>

                                @endif


                                <span>

                                    <strong>
                                        {{ $user->name }}
                                    </strong>

                                    <small>
                                        {{ $user->email }}
                                    </small>

                                </span>

                            </div>

                        </td>


                        {{-- ID --}}

                        <td>
                            <strong>
                                {{ $user->unique_id ?: '—' }}
                            </strong>
                        </td>


                        {{-- ACCOUNT TYPE --}}

                        <td>

                            @if($user->login_enabled)

                                <span class="badge-soft success">

                                    <i class="fa-solid fa-key me-1"></i>

                                    {{ $user->role }}

                                </span>

                            @else

                                <span class="badge-soft muted">

                                    <i class="fa-solid fa-user-tag me-1"></i>

                                    Faculty

                                </span>

                            @endif

                        </td>


                        {{-- CONTACT --}}

                        <td>
                            {{ $user->contact ?: '—' }}
                        </td>


                        {{-- ADDRESS --}}

                        <td title="{{ $user->address }}">

                            {{ Str::limit(
                                $user->address,
                                45
                            ) ?: '—' }}

                        </td>


                        {{-- STATUS --}}

                        <td>

                            <span
                                class="badge-soft {{ $user->status === 'Active' ? 'success' : 'muted' }}"
                            >
                                {{ $user->status }}
                            </span>

                        </td>


                        {{-- ACTIONS --}}

                        <td class="text-nowrap">



                            {{-- VIEW PROFILE & ASSET HISTORY --}}

                            <a
                                href="{{ route('users.asset-history', $user) }}"
                                class="btn btn-soft btn-icon"
                                title="View details & asset history"
                            >
                                <i class="fa-regular fa-eye"></i>
                            </a>

                            {{-- ASSIGN --}}

                            @permission('users','assign')

                                <button
                                    class="btn btn-soft btn-icon assign-asset-button"
                                    type="button"
                                    title="Assign asset"
                                    data-bs-toggle="modal"
                                    data-bs-target="#assignAssetModal"
                                    data-user-name="{{ $user->name }}"
                                    data-action="{{ route('users.assign-asset',$user) }}"
                                    @disabled($availableAssets->isEmpty())
                                >
                                    <i class="fa-solid fa-laptop-file"></i>
                                </button>

                            @endpermission


                            {{-- EDIT --}}

                            @permission('users','update')

                                <button
                                    class="btn btn-soft btn-icon"
                                    type="button"
                                    title="Edit user"
                                    data-bs-toggle="modal"
                                    data-bs-target="#editUserModal{{ $user->id }}"
                                >
                                    <i class="fa-regular fa-pen-to-square"></i>
                                </button>

                            @endpermission


                            {{-- DELETE --}}

                            @permission('users','delete')

                                <form
                                    class="d-inline"
                                    method="POST"
                                    action="{{ route(
                                        'users.destroy',
                                        $user
                                    ) }}"
                                    data-confirm
                                    data-confirm-title="Delete Faculty?"
                                    data-confirm-message="This will permanently delete {{ $user->name }}."
                                    data-confirm-label="Delete Faculty"
                                >

                                    @csrf
                                    @method('DELETE')


                                    <button
                                        class="btn btn-soft btn-icon"
                                        type="submit"
                                        title="Delete faculty"
                                    >
                                        <i class="fa-regular fa-trash-can text-danger"></i>
                                    </button>

                                </form>

                            @endpermission

                        </td>

                        @endif

                    </tr>


                @empty

                    <tr>

                        <td
                            colspan="7"
                            class="text-center py-5 text-secondary"
                        >

                            <i class="fa-solid fa-users fa-2x mb-3 d-block"></i>

                            No
                            {{
                                $selectedRole
                                    ? strtolower($selectedRole).' access accounts'
                                    : 'faculties'
                            }}
                            found.

                        </td>

                    </tr>

                @endforelse

            </tbody>

        </table>

    </div>


    {{-- =====================================================
         DATATABLE FOOTER
    ====================================================== --}}

    <div class="user-table-footer">

        <div class="user-table-info">

            Showing
            {{ $users->firstItem() ?? 0 }}
            to
            {{ $users->lastItem() ?? 0 }}
            of
            {{ $users->total() }}
            entries

        </div>


        <div class="user-pagination">

            @include('partials.pagination',[
                'paginator' => $users
            ])

        </div>

    </div>

</div>


{{-- =========================================================
     CREATE
========================================================= --}}

@permission('users','create')

    @include('users.form',[
        'user' => null
    ])

@endpermission


{{-- =========================================================
     EDIT
========================================================= --}}

@permission('users','update')

    @foreach($users as $user)

        @include('users.form',[
            'user' => $user
        ])

    @endforeach

@endpermission


{{-- =========================================================
     ASSIGN ASSET MODAL
========================================================= --}}

@permission('users','assign')

<div
    class="modal fade"
    id="assignAssetModal"
    tabindex="-1"
    aria-labelledby="assignAssetModalTitle"
    aria-hidden="true"
>

    <div class="modal-dialog modal-dialog-centered">

        <div class="modal-content">

            <form
                method="POST"
                action="#"
                id="assignAssetForm"
            >

                @csrf


                <div class="modal-header">

                    <div>

                        <h2
                            class="modal-title fs-5"
                            id="assignAssetModalTitle"
                        >
                            Assign Asset
                        </h2>

                        <p class="mb-0 mt-1 text-secondary small">

                            Select an available asset for

                            <strong id="assignAssetUser">
                                this faculty
                            </strong>.

                        </p>

                    </div>


                    <button
                        type="button"
                        class="btn-close"
                        data-bs-dismiss="modal"
                        aria-label="Close"
                    ></button>

                </div>


                <div class="modal-body">

                    @if($availableAssets->isNotEmpty())

                        <div class="row g-3">


                            <div class="col-sm-5">

                                <label
                                    class="form-label"
                                    for="assignAssetType"
                                >
                                    Asset Type *
                                </label>

                                <select
                                    class="form-select"
                                    id="assignAssetType"
                                    name="asset_type_id"
                                    required
                                >

                                    <option value="">
                                        Select type
                                    </option>


                                    @foreach(
                                        $availableAssets
                                            ->pluck('type')
                                            ->filter()
                                            ->unique('id')
                                            ->sortBy('name')
                                        as $availableType
                                    )

                                        <option
                                            value="{{ $availableType->id }}"
                                        >
                                            {{ $availableType->name }}
                                        </option>

                                    @endforeach

                                </select>

                            </div>


                            <div class="col-sm-7">

                                <label
                                    class="form-label"
                                    for="assignAssetSelect"
                                >
                                    Available Asset *
                                </label>


                                <select
                                    class="form-select"
                                    id="assignAssetSelect"
                                    name="asset_id"
                                    required
                                    disabled
                                >

                                    <option value="">
                                        Select type first
                                    </option>


                                    @foreach($availableAssets as $availableAsset)

                                        <option
                                            value="{{ $availableAsset->id }}"
                                            data-type="{{ $availableAsset->asset_type_id }}"
                                            hidden
                                        >
                                            {{ $availableAsset->asset_tag }}
                                            —
                                            {{ $availableAsset->name }}
                                            ({{ $availableAsset->status }})
                                        </option>

                                    @endforeach

                                </select>

                            </div>

                        </div>


                        <div class="assign-asset-note">

                            <i class="fa-solid fa-circle-info"></i>

                            <span>
                                Only unassigned assets are listed.
                                In Stock assets become Active after assignment.
                            </span>

                        </div>

                    @else

                        <div class="empty-assignment-state">

                            <i class="fa-solid fa-laptop-circle-xmark"></i>

                            <strong>
                                No assets available
                            </strong>

                            <span>
                                Add a new asset or unassign an existing one first.
                            </span>

                        </div>

                    @endif

                </div>


                <div class="modal-footer">

                    <button
                        type="button"
                        class="btn btn-soft"
                        data-bs-dismiss="modal"
                    >
                        Cancel
                    </button>


                    <button
                        type="submit"
                        class="btn btn-primary"
                        @disabled($availableAssets->isEmpty())
                    >
                        <i class="fa-solid fa-link me-2"></i>
                        Assign Asset
                    </button>

                </div>

            </form>

        </div>

    </div>

</div>

@endpermission


{{-- =========================================================
     IMPORT
========================================================= --}}

@permission('users','import')

    @include('partials.user-import-modal')

@endpermission


@endsection


{{-- =========================================================
     AUTO SEARCH + STATUS FILTER
========================================================= --}}

@push('scripts')

<script>
document.addEventListener('DOMContentLoaded', function () {

    const form =
        document.getElementById('userFilterForm');

    const search =
        document.getElementById('userSearch');


    if (form) {

        let searchTimer;
        let submitting = false;


        function submitFilters() {

            if (submitting) {
                return;
            }

            submitting = true;

            form.classList.add(
                'user-filter-loading'
            );

            form.submit();
        }


        /*
        |--------------------------------------------------------------------------
        | Status
        |--------------------------------------------------------------------------
        */

        document
            .querySelectorAll('.user-auto-filter')
            .forEach(function (element) {

                element.addEventListener(
                    'change',
                    function () {

                        submitFilters();

                    }
                );

            });


        /*
        |--------------------------------------------------------------------------
        | Search
        |--------------------------------------------------------------------------
        */

        if (search) {

            search.addEventListener(
                'input',
                function () {

                    clearTimeout(searchTimer);

                    searchTimer =
                        setTimeout(
                            submitFilters,
                            450
                        );

                }
            );

        }

    }


    /*
    |--------------------------------------------------------------------------
    | Assign Asset
    |--------------------------------------------------------------------------
    */

    @permission('users','assign')

    document
        .getElementById('assignAssetModal')
        ?.addEventListener(
            'show.bs.modal',
            event => {

                const button =
                    event.relatedTarget;

                const assignForm =
                    document.getElementById(
                        'assignAssetForm'
                    );

                const user =
                    document.getElementById(
                        'assignAssetUser'
                    );

                const type =
                    document.getElementById(
                        'assignAssetType'
                    );

                const select =
                    document.getElementById(
                        'assignAssetSelect'
                    );


                assignForm.action =
                    button.dataset.action;

                user.textContent =
                    button.dataset.userName;


                if (type) {
                    type.value = '';
                }


                if (select) {

                    select.value = '';

                    select.disabled = true;

                    select.options[0].textContent =
                        'Select type first';


                    [...select.options]
                        .slice(1)
                        .forEach(option => {

                            option.hidden = true;

                        });

                }

            }
        );


    document
        .getElementById('assignAssetType')
        ?.addEventListener(
            'change',
            function () {

                const select =
                    document.getElementById(
                        'assignAssetSelect'
                    );

                const selectedType =
                    this.value;


                select.value = '';

                select.disabled =
                    !selectedType;


                select.options[0].textContent =
                    selectedType
                        ? 'Select an asset'
                        : 'Select type first';


                [...select.options]
                    .slice(1)
                    .forEach(option => {

                        option.hidden =
                            option.dataset.type
                            !== selectedType;

                    });

            }
        );

    @endpermission

});
</script>

@endpush


{{-- =========================================================
     IMPORT VALIDATION AUTO OPEN
========================================================= --}}

@if(
    app(\App\Services\PermissionService::class)
        ->allows('users','import')
    &&
    (
        session('openUserImportModal')
        ||
        $errors->userImport->any()
    )
)

@push('scripts')

<script>
document.addEventListener(
    'DOMContentLoaded',
    function () {

        const modal =
            document.getElementById(
                'userImportModal'
            );

        if (modal) {

            bootstrap.Modal
                .getOrCreateInstance(modal)
                .show();

        }

    }
);
</script>

@endpush

@endif

