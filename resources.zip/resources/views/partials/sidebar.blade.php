@php
    $permissionService = app(\App\Services\PermissionService::class);
    $groups = config('sidebar', []);
@endphp

<aside class="sidebar" id="sidebar">
    <a class="brand" href="{{ route('dashboard') }}">
        <span class="sidebar-brand-icon">
            <img
                src="{{ \App\Support\PublicUrl::asset('static/img/agile-tech-logo.png') }}"
                alt=""
            >
        </span>
        <span class="brand-copy sidebar-brand-copy">
            <strong>Agile Tech</strong>
            <small>Solutions</small>
        </span>
    </a>

    <nav class="sidebar-nav">
        <div class="recently-opened" id="recentlyOpened" hidden>
            <span class="nav-caption">Recently Opened</span>
            <div id="recentlyOpenedLinks"></div>
        </div>

        <span class="nav-caption">Workspace</span>

        @if($permissionService->allows('dashboard'))
        <a href="{{ route('dashboard') }}"
           class="nav-link {{ request()->is('dashboard') ? 'active' : '' }}"
           title="Dashboard">
            <i class="fa-solid fa-chart-pie"></i>
            <span>Dashboard</span>
        </a>
        @endif

        @foreach($groups as $group)
            @php
                $visibleItems = collect($group['items'])->filter(fn ($item) => $permissionService->allows($item[5]));
                $groupActive = $visibleItems->contains(function ($item) {
                    return $item[0] !== '#' && request()->is($item[0]);
                });
            @endphp

            @if($visibleItems->isNotEmpty())
            <div class="nav-group {{ $groupActive ? 'is-active' : '' }}">
                <button class="nav-group-toggle {{ $groupActive ? 'active' : '' }}"
                        type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#{{ $group['id'] }}"
                        aria-expanded="{{ $groupActive ? 'true' : 'false' }}"
                        aria-controls="{{ $group['id'] }}">
                    <i class="fa-solid {{ $group['icon'] }} group-icon"></i>
                    <span>{{ $group['label'] }}</span>
                    <i class="fa-solid fa-chevron-down group-chevron"></i>
                </button>

                <div class="collapse nav-submenu {{ $groupActive ? 'show' : '' }}"
                     id="{{ $group['id'] }}"
                     data-group-label="{{ $group['label'] }}"
                     data-bs-parent=".sidebar-nav">

                    @foreach($visibleItems as $item)
                        @php
                            [$pattern, $icon, $label, $routeName] = array_slice($item, 0, 4);
                            $routeParameters = $item[4] ?? [];
                            $itemRole = $routeParameters['role'] ?? null;
                            $isActive = $pattern !== '#'
                                && request()->is($pattern)
                                && ($itemRole ? request('role') === $itemRole : !request('role'));
                            $url = ($routeName !== '#' && Route::has($routeName))
                                ? route($routeName, $routeParameters)
                                : '#';
                        @endphp

                        <a href="{{ $url }}"
                           class="nav-link {{ $isActive ? 'active' : '' }} {{ $url === '#' ? 'disabled-link' : '' }}"
                           title="{{ $label }}">
                            <i class="fa-solid {{ $icon }}"></i>
                            <span>{{ $label }}</span>
                        </a>
                    @endforeach

                </div>
            </div>
            @endif
        @endforeach
    </nav>

    <!-- <div class="sidebar-help">
        <i class="fa-regular fa-circle-question"></i>
        <div>
            <strong>Need help?</strong>
            <small>Contact IT support</small>
        </div>
    </div> -->
</aside>
