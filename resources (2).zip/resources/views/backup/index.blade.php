@extends('layouts.app')
@section('title','Backup & Recovery')
@section('content')
@include('partials.page-header',[
    'title'=>'Backup & Recovery',
    'description'=>'Secure data protection, scheduled backups, and guided recovery tools.'
])

<section class="backup-coming-soon panel">
    <div class="backup-glow backup-glow-one"></div>
    <div class="backup-glow backup-glow-two"></div>

    <div class="backup-coming-copy">
        <span class="backup-status"><i class="fa-solid fa-sparkles"></i> Coming Soon</span>
        <div class="backup-hero-icon">
            <i class="fa-solid fa-cloud-arrow-up"></i>
            <span><i class="fa-solid fa-shield-halved"></i></span>
        </div>
        <p class="backup-eyebrow">Backup & Recovery Center</p>
        <h2>Your data protection workspace is being prepared.</h2>
        <p class="backup-description">A reliable workspace for automated backups, restore points, recovery history, and secure business continuity is under development.</p>

        <div class="backup-feature-grid">
            <article>
                <span><i class="fa-solid fa-calendar-check"></i></span>
                <div><strong>Scheduled Backups</strong><small>Automated daily and custom backup plans</small></div>
            </article>
            <article>
                <span><i class="fa-solid fa-clock-rotate-left"></i></span>
                <div><strong>Point-in-time Restore</strong><small>Recover data from verified restore points</small></div>
            </article>
            <article>
                <span><i class="fa-solid fa-lock"></i></span>
                <div><strong>Secure Storage</strong><small>Protected and encrypted backup archives</small></div>
            </article>
        </div>

        <div class="backup-note"><i class="fa-solid fa-circle-info"></i><span>This module is not active yet. No backup or restore actions are currently being performed.</span></div>
    </div>
</section>

<style>
.backup-coming-soon{position:relative;min-height:570px;display:grid;place-items:center;overflow:hidden;padding:56px 24px;background:linear-gradient(145deg,var(--card-bg),color-mix(in srgb,var(--accent-soft) 42%,var(--card-bg)))}
.backup-coming-soon:before{content:"";position:absolute;inset:22px;border:1px dashed color-mix(in srgb,var(--accent-color) 20%,var(--border-color));border-radius:18px;pointer-events:none}
.backup-glow{position:absolute;border-radius:50%;filter:blur(3px);pointer-events:none}
.backup-glow-one{width:330px;height:330px;left:-140px;top:-150px;background:color-mix(in srgb,var(--accent-color) 9%,transparent)}
.backup-glow-two{width:290px;height:290px;right:-115px;bottom:-140px;background:rgba(10,191,189,.1)}
.backup-coming-copy{position:relative;z-index:1;width:min(850px,100%);text-align:center}
.backup-status{display:inline-flex;align-items:center;gap:7px;margin-bottom:24px;padding:7px 12px;border:1px solid color-mix(in srgb,var(--accent-color) 24%,var(--border-color));border-radius:30px;background:var(--accent-soft);color:var(--accent-color);font-size:10px;font-weight:800;letter-spacing:1.2px;text-transform:uppercase}
.backup-hero-icon{position:relative;width:94px;height:94px;display:grid;place-items:center;margin:0 auto 23px;border:1px solid color-mix(in srgb,var(--accent-color) 22%,var(--border-color));border-radius:27px;background:var(--card-bg);box-shadow:0 18px 45px color-mix(in srgb,var(--accent-color) 17%,transparent);color:var(--accent-color);font-size:38px}
.backup-hero-icon>span{position:absolute;width:31px;height:31px;right:-8px;bottom:-7px;display:grid;place-items:center;border:4px solid var(--card-bg);border-radius:50%;background:#0abfbd;color:#fff;font-size:11px}
.backup-eyebrow{margin:0 0 8px;color:#0abfbd;font-size:10px;font-weight:800;letter-spacing:1.7px;text-transform:uppercase}
.backup-coming-copy h2{max-width:670px;margin:0 auto;color:var(--text-primary);font-size:clamp(25px,3vw,38px);font-weight:800;line-height:1.2;letter-spacing:-1px}
.backup-description{max-width:660px;margin:15px auto 30px;color:var(--text-muted);font-size:13px;line-height:1.7}
.backup-feature-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;text-align:left}
.backup-feature-grid article{min-height:90px;display:flex;align-items:center;gap:12px;padding:15px;border:1px solid var(--border-color);border-radius:13px;background:color-mix(in srgb,var(--card-bg) 88%,transparent)}
.backup-feature-grid article>span{width:39px;height:39px;flex:none;display:grid;place-items:center;border-radius:10px;background:var(--accent-soft);color:var(--accent-color)}
.backup-feature-grid article:nth-child(2)>span{background:rgba(10,191,189,.12);color:#0abfbd}
.backup-feature-grid article:nth-child(3)>span{background:rgba(16,185,129,.12);color:var(--success)}
.backup-feature-grid article div{display:flex;flex-direction:column;gap:4px}
.backup-feature-grid strong{font-size:12px;color:var(--text-primary)}
.backup-feature-grid small{font-size:10px;line-height:1.45;color:var(--text-muted)}
.backup-note{display:inline-flex;align-items:center;gap:8px;margin-top:25px;color:var(--text-muted);font-size:10px}
.backup-note i{color:var(--accent-color)}
@media(max-width:767px){.backup-coming-soon{min-height:0;padding:46px 20px}.backup-coming-soon:before{inset:12px}.backup-feature-grid{grid-template-columns:1fr}.backup-coming-copy h2{font-size:26px}.backup-note{align-items:flex-start;text-align:left}}
</style>
@endsection
